﻿using System;

namespace UgurcangursuWeek._1
{
    public class Cities
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Region { get; set; }
        public int Population { get; set; }
        public int NumberofDistricts { get; set; }
        public int Altitude { get; set; }

    }

}
