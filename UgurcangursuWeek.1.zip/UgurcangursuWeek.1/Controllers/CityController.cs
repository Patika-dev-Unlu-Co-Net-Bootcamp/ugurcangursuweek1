﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace UgurcangursuWeek._1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class CityController : Controller
    {
        //created new list for fake datas 
        List<Cities> cityList = new List<Cities>()
            {
                new Cities()
                {
                    Id=1,
          Name="Bursa",
          Region="Marmara",
          Population=7000000,
          NumberofDistricts=9,
        Altitude=1,

                },
                 new Cities()
                {
                    Id=34,
          Name="İstanbul",
          Region="Marmara",
          Population=12000000,
          NumberofDistricts=17,
        Altitude=1,

                },
                  new Cities()
                {
                    Id=6,
          Name="Ankara",
          Region="İçAnadolu",
          Population=1000000,
          NumberofDistricts=12,
        Altitude=41,

                }
          };


        /*list all members*/
        [HttpGet]
        public IActionResult Get()
        {
            if (cityList is not null)
                return Ok(cityList);

            return BadRequest();
        }



        /*list selected item with id*/
        [HttpGet("{id}")]
        public IActionResult Get(int Id)
        {
            var Cities = cityList.SingleOrDefault(x => x.Id == Id);

            if (Cities is not null)
                return Ok(Cities);

            return BadRequest();

        }



        [HttpGet("RegionCities/{Id}")]
        public IActionResult GetByRegion(int Id)
        {

            var _citylist = cityList.Where(x => x.Id == Id).ToList<Cities>();

            if (_citylist is null)
                return BadRequest();

            return Ok(_citylist);

        }




        [HttpPost]
        public IActionResult Post([FromBody] Cities _Cities)
        {
            var cities = cityList.SingleOrDefault(x => x.Name == _Cities.Name);

            if (cities is not null)
                return BadRequest();

            cityList.Add(_Cities);
            return Ok(cityList);
        }




        [HttpPut("{Id}")]
        public IActionResult Put(int id, [FromQuery] Cities _Cities)
        {
            var cities = cityList.SingleOrDefault(x => x.Id == id);

            if (cities is null)
                return BadRequest();

            cities.Id = _Cities.Id != default ? _Cities.Id : cities.Id;
            cities.Name= _Cities.Name != default ? _Cities.Name : cities.Name;
            cities.Population = _Cities.Population != default ? _Cities.Population : cities.Population;

            return Ok(cityList);
        }

       
            //this method will delete the data selected with id
            [HttpDelete("{id}")]
        public IActionResult Delete(int Id)
        {
            var cities=cityList.SingleOrDefault(x => x.Id == Id);

            if (cities is null)
                return BadRequest();

           cityList.Remove(cities);
            return Ok(cityList);
        }


















    }
}

